#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Gpgmepp" for configuration "Release"
set_property(TARGET Gpgmepp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Gpgmepp PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libgpgmepp.7.0.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libgpgmepp.7.dylib"
  )

list(APPEND _cmake_import_check_targets Gpgmepp )
list(APPEND _cmake_import_check_files_for_Gpgmepp "${_IMPORT_PREFIX}/lib/libgpgmepp.7.0.0.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
